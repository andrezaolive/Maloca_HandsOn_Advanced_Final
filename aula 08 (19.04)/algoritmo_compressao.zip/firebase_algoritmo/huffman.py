from collections import Counter
import heapq

class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

def build_huffman_tree(data):
    frequency = Counter(data)
    heap = [HuffmanNode(char, freq) for char, freq in frequency.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = HuffmanNode(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(heap, merged)

    return heap[0]

def build_huffman_codes(node, prefix="", code_dict={}):
    if node:
        if node.char:
            code_dict[node.char] = prefix
        build_huffman_codes(node.left, prefix + "0", code_dict)
        build_huffman_codes(node.right, prefix + "1", code_dict)
    return code_dict

def huffman_compress(data):
    root = build_huffman_tree(data)
    huffman_codes = build_huffman_codes(root)
    compressed_data = "".join(huffman_codes[char] for char in data)
    return compressed_data, huffman_codes
