import json
import heapq
from collections import Counter
import pyrebase

# === CONFIGURAÇÃO DO FIREBASE ===
with open("firebase_config.json") as f:
    firebase_config = json.load(f)

firebase = pyrebase.initialize_app(firebase_config)
db = firebase.database()

# === HUFFMAN ===
class HuffmanNode:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

def build_huffman_tree(data):
    frequency = Counter(data)
    heap = [HuffmanNode(char, freq) for char, freq in frequency.items()]
    heapq.heapify(heap)
    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)
        merged = HuffmanNode(None, left.freq + right.freq)
        merged.left = left
        merged.right = right
        heapq.heappush(heap, merged)
    return heap[0]

def build_huffman_codes(node, prefix="", code_dict={}):
    if node:
        if node.char:
            code_dict[node.char] = prefix
        build_huffman_codes(node.left, prefix + "0", code_dict)
        build_huffman_codes(node.right, prefix + "1", code_dict)
    return code_dict

def huffman_compress(data):
    root = build_huffman_tree(data)
    huffman_codes = build_huffman_codes(root)
    compressed_data = "".join(huffman_codes[char] for char in data)
    return compressed_data, huffman_codes

# === COMPRESSÃO DOS DADOS DO NÓ "dados" ===
def comprimir_dados_do_nodo():
    dados = db.child("dados").get().val()
    if not dados:
        print("❌ Nenhum dado encontrado no nó 'dados'.")
        return

    for timestamp, leitura in dados.items():
        temp = str(leitura.get("temperatura", ""))
        bpm = str(leitura.get("bpm", ""))
        
        if not temp or not bpm:
            continue

        # Remove ponto da temperatura (ex: "36.5" → "365")
        raw_data = bpm + temp.replace(".", "")
        
        compressed_data, huffman_codes = huffman_compress(raw_data)

        # Salva os dados comprimidos em outro nó
        db.child("dados_comprimidos").child(timestamp).set({
            "original": raw_data,
            "comprimido": compressed_data,
            "huffman": huffman_codes
        })
        print(f"✅ Dado {timestamp} comprimido e salvo com sucesso!")

def comprimir_dados_do_nodo_alarme():
    alarmes = db.child("alarme").get().val()
    if not alarmes:
        print("❌ Nenhum dado encontrado no nó 'alarme'.")
        return

    for timestamp, evento in alarmes.items():
        texto = json.dumps(evento, ensure_ascii=False)  # Transforma o objeto em string

        compressed_data, huffman_codes = huffman_compress(texto)

        db.child("alarme_comprimido").child(timestamp).set({
            "original": texto,
            "comprimido": compressed_data,
            "huffman": huffman_codes
        })
        print(f"🔔 Alarme {timestamp} comprimido e salvo com sucesso!")


if __name__ == "__main__":
    comprimir_dados_do_nodo()
    comprimir_dados_do_nodo_alarme()
