const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

let dados = { temperatura: 0, bpm: 0 };

app.use(cors());
app.use(express.json());

app.post('/medicao', (req, res) => {
    dados = req.body;
    console.log('Dados recebidos:', dados);
    res.sendStatus(200);
});

app.get('/medicao', (req, res) => {
    res.json(dados);
});

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
