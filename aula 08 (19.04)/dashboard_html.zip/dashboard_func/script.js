// Configuração Firebase compatível
const firebaseConfig = {
    apiKey: "AIzaSyD7qaLMBzdHsXpzqZ6BYwmozD1nouIVc6M",
    authDomain: "maloca-advanced.firebaseapp.com",
    databaseURL: "https://maloca-advanced-default-rtdb.firebaseio.com",
    projectId: "maloca-advanced",
    storageBucket: "maloca-advanced.firebasestorage.app",
    messagingSenderId: "568600637413",
    appId: "1:568600637413:web:7a9bbebf2517a2fea1c90c"
  };
  
  firebase.initializeApp(firebaseConfig);
  const database = firebase.database();
  
  // Configuração dos gráficos
  const tempCtx = document.getElementById('tempChart').getContext('2d');
  const bpmCtx = document.getElementById('bpmChart').getContext('2d');
  
  let notificationCount = 0;
  let criticalAlerts = 0;
  const monitoringStartTime = new Date();
  
  const tempChart = new Chart(tempCtx, {
      type: "line",
      data: { labels: [], datasets: [{ label: "Temperatura (°C)", data: [], borderColor: "#006dac", backgroundColor: "rgba(0, 109, 172, 0.1)", borderWidth: 3, pointBackgroundColor: "#ffffff", pointBorderColor: "#006dac", pointRadius: 5, pointHoverRadius: 7, fill: true, tension: 0.3 }] },
      options: getChartOptions(20, 40, 1)
  });
  
  const bpmChart = new Chart(bpmCtx, {
      type: "line",
      data: { labels: [], datasets: [{ label: "BPM", data: [], borderColor: "#56d497", backgroundColor: "rgba(86, 212, 151, 0.1)", borderWidth: 3, pointBackgroundColor: "#ffffff", pointBorderColor: "#56d497", pointRadius: 5, pointHoverRadius: 7, fill: true, tension: 0.3 }] },
      options: getChartOptions(0, 200, 20)
  });
  
  function getChartOptions(min, max, stepSize) {
      return {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
              y: { min: min, max: max, grid: { color: "rgba(0, 0, 0, 0.05)" }, ticks: { color: "#333333", stepSize: stepSize } },
              x: { grid: { color: "rgba(0, 0, 0, 0.05)" }, ticks: { color: "#333333" } }
          },
          plugins: {
              legend: {
                  labels: {
                      color: "#333333",
                      font: { weight: 'bold' }
                  }
              },
              zoom: {
                pan: {
                  enabled: true,
                  mode: 'x'
                },
                zoom: {
                  wheel: {
                    enabled: true
                  },
                  pinch: {
                    enabled: true
                  },
                  mode: 'x',
                }
              }              
          }
      };
  }
  
  function updateChart(chart, label, data) {
      chart.data.labels.push(label);
      chart.data.datasets[0].data.push(data);
      if (chart.data.labels.length > 15) {
          chart.data.labels.shift();
          chart.data.datasets[0].data.shift();
      }
      chart.update();
  }
  
  function addToHistory(time, temp, bpm, isCritical = false) {
      const historico = document.getElementById("lista-historico");
      let item = document.createElement("div");
      item.className = `event-item ${isCritical ? 'alert' : ''}`;
      item.innerHTML = `<span class="event-time">${time}</span><span class="event-details">Temp: ${temp.toFixed(1)}°C | BPM: ${bpm}</span>`;
      historico.prepend(item);
      if (historico.children.length > 20) historico.removeChild(historico.lastChild);
  }
  
  function addNotification(message, isCritical = false) {
      notificationCount++;
      criticalAlerts += isCritical ? 1 : 0;
      document.getElementById('notificationCounter').textContent = criticalAlerts > 0 ? criticalAlerts : notificationCount;
      const notificationList = document.getElementById('notificationList');
      const notificationItem = document.createElement('div');
      notificationItem.className = `notification-item ${isCritical ? 'critical' : ''}`;
      const now = new Date();
      const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      notificationItem.innerHTML = `<div class="notification-time">${timeString}</div><div class="notification-message">${message}</div>`;
      notificationList.prepend(notificationItem);
      if (isCritical) {
          const icon = document.querySelector('.notifications img');
          icon.classList.add('notification-alert');
          setTimeout(() => icon.classList.remove('notification-alert'), 5000);
      }
  }
  
  function updateMonitoringTime() {
      const now = new Date();
      const diffMs = now - monitoringStartTime;
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      document.getElementById('monitoringTime').textContent = `${diffHours > 0 ? diffHours + ' hora' + (diffHours > 1 ? 's' : '') + ' e ' : ''}${diffMinutes} minuto${diffMinutes !== 1 ? 's' : ''}`;
  }
  
  function iniciarMonitoramentoTempoReal() {
      const dadosRef = database.ref('dados');
  
      dadosRef.on('value', (snapshot) => {
          const dados = snapshot.val();
          if (!dados) return;
  
          const registrosOrdenados = Object.values(dados).sort((a, b) => a.timestamp - b.timestamp);
  
          tempChart.data.labels = [];
          tempChart.data.datasets[0].data = [];
          bpmChart.data.labels = [];
          bpmChart.data.datasets[0].data = [];
  
          registrosOrdenados.forEach((registro) => {
              const hora = new Date(registro.timestamp).toLocaleTimeString([], {
                  hour: '2-digit', minute: '2-digit'
              });
  
              const temp = registro.temperatura;
              const bpm = registro.bpm;
  
              updateChart(tempChart, hora, temp);
              updateChart(bpmChart, hora, bpm);
  
              document.getElementById('temperatura').textContent = temp.toFixed(1);
              document.getElementById('bpm').textContent = bpm;
  
              const isTempCritical = temp > 37.5 || temp < 35.5;
              const isBPMCritical = bpm < 60 || bpm > 100;
              const isCritical = isTempCritical || isBPMCritical;
  
              if (isCritical) {
                  let message = '';
                  if (isTempCritical && isBPMCritical) {
                      message = `Alerta: Temperatura anormal (${temp}°C) e BPM anormal (${bpm})`;
                  } else if (isTempCritical) {
                      message = `Alerta: Temperatura anormal (${temp}°C)`;
                  } else {
                      message = `Alerta: BPM anormal (${bpm})`;
                  }
                  addNotification(message, true);
              }
  
              addToHistory(hora, temp, bpm, isCritical);
          });
  
          tempChart.update();
          bpmChart.update();
      });
  }
  
  document.querySelectorAll('.device-btn').forEach(btn => {
      btn.addEventListener('click', function() {
          this.classList.toggle('active');
          this.textContent = this.classList.contains('active') ? this.textContent.replace('Ativar', 'Desativar') : this.textContent.replace('Desativar', 'Ativar');
      });
  });
  
  document.getElementById('notificationIcon').addEventListener('click', function(e) {
      e.stopPropagation();
      const panel = document.getElementById('notificationPanel');
      panel.classList.toggle('show');
      notificationCount = 0;
      criticalAlerts = 0;
      document.getElementById('notificationCounter').textContent = '0';
  });
  
  document.addEventListener('click', function() {
      document.getElementById('notificationPanel').classList.remove('show');
  });
  
  document.getElementById('notificationPanel').addEventListener('click', function(e) {
      e.stopPropagation();
  });
  
  document.addEventListener('DOMContentLoaded', () => {
      iniciarMonitoramentoTempoReal();
      updateMonitoringTime();
      setInterval(updateMonitoringTime, 60000);
  });