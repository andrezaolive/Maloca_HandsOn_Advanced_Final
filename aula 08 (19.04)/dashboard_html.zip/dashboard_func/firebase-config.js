// Configuração do Firebase (substitua com seus dados)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getDatabase }  from "https://www.gstatic.com/firebasejs/9.6.10/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyD7qaLMBzdHsXpzqZ6BYwmozD1nouIVc6M",
    authDomain: "maloca-advanced.firebaseapp.com",
    projectId: "maloca-advanced",
    storageBucket: "maloca-advanced.firebasestorage.app",
    messagingSenderId: "568600637413",
    appId: "1:568600637413:web:7a9bbebf2517a2fea1c90c",
    databaseURL: "https://maloca-advanced-default-rtdb.firebaseio.com/"
  };
  
 // Inicialização
firebase.initializeApp(firebaseConfig);
const database = firebase.database();
